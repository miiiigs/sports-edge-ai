# ChatGPT Project Handoff

Bundle date: 2026-08-19

## What this bundle contains

- exact tracked modifications via `git_status.txt` and `git_diff.patch`
- untracked project files via `untracked_files.txt`
- changed and priority text files copied in full when small enough
- large text artifacts included as previews when full copy would be heavy

## Current state

Current high-signal state:
- The football migration slice is now implemented through Day 12 for the currently loaded scope, with Day 12 honestly marked `PARTIAL` because the required point-in-time-valid xG path is still missing.
- Day 7, Day 8, Day 9, Day 10, and Day 11A all have explicit acceptance evidence and reproducible repo-backed artifacts.
- Day 10 still provides the frozen fair-model pricing authority, and Day 11A now consumes that authority unchanged instead of rebuilding model prices.
- The real historical/demo Day 11A manager run produced `28992` decision records: `10299` `PRELIMINARY_CANDIDATE` and `18693` `NO_BET`.
- `DAY11_MANAGER_CORE_READY = YES` is now supported by implemented code, tests, technical artifacts, and manager-facing outputs.
- `LIVE_PAPER_PIPELINE_READY = NO` remains the honest status because live provider and current forward-fit dependencies are still unresolved.
- Day 10 derives `1X2`, `BTTS`, goals totals, Asian handicap, and corner totals from frozen pre-match model objects only.
- Day 11A uses settlement-aware edge and minimum-price arithmetic directly from Day 10 `W` and `L`, plus normalized market snapshots, booksum validation, and Shin de-vig.
- The currently supplied in-repo market snapshot path is a real historical/demo archived closing `1X2` slate, so the manager build is honest about its current input coverage and does not overstate point-in-time-live provenance.
- The real Day 12 run consumed `10299` Day 11 preliminary candidates and produced `4317` `EXPERIMENTAL_CANDIDATE` plus `5982` `BLOCKED_MISSING_XG_DATA`.
- `FOOTBALL_LOGICAL_PIPELINE_READY = NO`, `LIVE_PAPER_PIPELINE_READY = NO`, and `TENNIS AUTHORIZED = NO` remain the honest status after Day 12.
- The next football dependency is the truthful xG/data-path resolution needed to move Day 12 from `PARTIAL` to `COMPLETE`, followed by the football logical-pipeline freeze before tennis begins.
- Every completed milestone must now ship machine-readable artifacts, reproducibility manifests, a human-readable product/output report, and a compact latest/current artifact.

## Immediate next work

- keep the implemented Day 12 layer frozen unless a real correctness issue is found
- do not reopen closed Day 7 through Day 12 arithmetic layers casually
- keep Day 11A's product boundary intact: frozen Day 10 fair price plus supplied market snapshot yields preliminary manager decisions, not live betting readiness
- preserve the implemented Day 11A normalized market contract, Shin/reference booksum path, settlement-aware edge arithmetic, full decision logging, and Day 12 safeguard dispositions as the new frozen upstream baseline
- preserve the historical/demo archived closing `1X2` limitation explicitly and do not upgrade it into a genuine point-in-time-live market snapshot claim
- resolve the point-in-time-valid xG input dependency honestly before upgrading Day 12 beyond `PARTIAL`
- handle live provider integration and current forward-fit readiness as parallel dependencies, not as excuses to reopen the accepted Day 11A or Day 12 core logic
- stop short of tennis or shared later-day work until football is explicitly re-authorized

## Files included

- SPORTS_EDGE_AI_CODEX_MASTER_HANDOFF.md [full_copy]
- SPORTS_EDGE_AI_MASTER_README.md [full_copy]
- SPORTS_EDGE_AI_PROGRESS_CHECKLIST.md [full_copy]
- code/pyproject.toml [full_copy]
- code/src/sports_ai/agents/football/gap_ratings.py [full_copy]
- code/src/sports_ai/agents/market/devig.py [full_copy]
- code/src/sports_ai/dashboard/__init__.py [full_copy]
- code/src/sports_ai/dashboard/app.py [full_copy]
- code/src/sports_ai/dashboard/fixture_provider.py [full_copy]
- code/src/sports_ai/dashboard/models.py [full_copy]
- code/src/sports_ai/dashboard/prediction_service.py [full_copy]
- code/src/sports_ai/dashboard/services.py [full_copy]
- code/src/sports_ai/dashboard/snapshot_service.py [full_copy]
- code/src/sports_ai/dashboard/storage.py [full_copy]
- code/src/sports_ai/dashboard/templates/_match_card.html [full_copy]
- code/src/sports_ai/dashboard/templates/base.html [full_copy]
- code/src/sports_ai/dashboard/templates/candidates.html [full_copy]
- code/src/sports_ai/dashboard/templates/candidates_content.html [full_copy]
- code/src/sports_ai/dashboard/templates/dashboard.html [full_copy]
- code/src/sports_ai/dashboard/templates/dashboard_sections.html [full_copy]
- code/src/sports_ai/dashboard/templates/match_detail.html [full_copy]
- code/src/sports_ai/dashboard/templates/match_detail_content.html [full_copy]
- code/src/sports_ai/dashboard/templates/matches.html [full_copy]
- code/src/sports_ai/dashboard/templates/matches_table.html [full_copy]
- code/src/sports_ai/dashboard/templates/predictions.html [full_copy]
- code/src/sports_ai/dashboard/templates/predictions_table.html [full_copy]
- code/src/sports_ai/experiments/football_day10_market_pricing.py [full_copy]
- code/src/sports_ai/experiments/football_day10_product_outputs.py [full_copy]
- code/src/sports_ai/experiments/football_day11_manager_core.py [full_copy]
- code/src/sports_ai/experiments/football_day11_product_outputs.py [full_copy]
- code/src/sports_ai/experiments/football_day12_product_outputs.py [full_copy]
- code/src/sports_ai/experiments/football_day12_safeguards.py [full_copy]
- code/src/sports_ai/experiments/football_day8_goal_conversion.py [full_copy]
- code/src/sports_ai/experiments/football_day9_scoreline_model.py [full_copy]
- code/src/sports_ai/experiments/football_gap_corners_walkforward.py [full_copy]
- code/src/sports_ai/experiments/football_gap_lambda_fitting.py [full_copy]
- code/src/sports_ai/experiments/football_gap_shots_on_target_walkforward.py [full_copy]
- code/src/sports_ai/experiments/football_gap_shots_walkforward.py [full_copy]
- code/src/sports_ai/tools/chatgpt_handoff_bundle.py [full_copy]
- code/tests/test_chatgpt_handoff_bundle.py [full_copy]
- code/tests/test_football_dashboard.py [full_copy]
- code/tests/test_football_day10_market_pricing.py [full_copy]
- code/tests/test_football_day10_product_outputs.py [full_copy]
- code/tests/test_football_day11_manager_core.py [full_copy]
- code/tests/test_football_day11_product_outputs.py [full_copy]
- code/tests/test_football_day12_safeguards.py [full_copy]
- code/tests/test_football_day8_goal_conversion.py [full_copy]
- code/tests/test_football_day9_scoreline_model.py [full_copy]
- code/tests/test_football_gap_corners_walkforward.py [full_copy]
- code/tests/test_football_gap_lambda_fitting.py [full_copy]
- code/tests/test_football_gap_shots_on_target_walkforward.py [full_copy]
- code/tests/test_football_gap_shots_walkforward.py [full_copy]
- docs/BLOCKERS.md [full_copy]
- docs/DECISION_LOG.md [full_copy]
- docs/EXPERIMENT_LOG.md [full_copy]
- docs/PROJECT_STATUS.md [full_copy]
- docs/REQUIREMENTS_TRACEABILITY.md [full_copy]
- pytest.ini [full_copy]
- research/football_research/decision_layer_audit_v3_2026-08-16.json [full_copy]
- research/football_research/decision_policy_validation_v3_2026-08-16.json [full_copy]
- research/football_research/decision_policy_validation_v3_2026-08-16.md [full_copy]
- research/football_research/football_data_quality_audit_v3_2026-08-15.json [full_copy]
- research/football_research/football_data_quality_audit_v3_2026-08-15.md [full_copy]
- research/football_research/football_day10_market_pricing_2026-08-18.md [full_copy]
- research/football_research/football_day11_manager_2026-08-18_devig_outputs.jsonl [preview_only]
- research/football_research/football_day11_manager_2026-08-18_joined_rows.jsonl [preview_only]
- research/football_research/football_day11_manager_2026-08-18_manifest.json [full_copy]
- research/football_research/football_day11_manager_2026-08-18_normalized_market_snapshots.jsonl [preview_only]
- research/football_research/football_day12_safeguards_2026-08-19_candidate_records.jsonl [preview_only]
- research/football_research/football_day12_safeguards_2026-08-19_manifest.json [full_copy]
- research/football_research/football_v3_optimizer_diagnostic_2026-08-15.json [full_copy]
- research/football_research/football_v3_optimizer_diagnostic_2026-08-15.md [full_copy]
- research/product_outputs/dashboard/FOOTBALL_DASHBOARD_V1_1_README.md [full_copy]
- research/product_outputs/dashboard/FOOTBALL_DASHBOARD_V1_README.md [full_copy]
- research/product_outputs/football/day10/FOOTBALL_DAY10_MODEL_PRICING_REPORT.md [full_copy]
- research/product_outputs/football/day10/football_day10_model_prices.csv [preview_only]
- research/product_outputs/football/day10/football_day10_model_prices.jsonl [preview_only]
- research/product_outputs/football/day10/football_day10_model_prices_sample.csv [full_copy]
- research/product_outputs/football/day10/football_day10_product_manifest.json [full_copy]
- research/product_outputs/football/day11/FOOTBALL_DAY11_MANAGER_REPORT.html [full_copy]
- research/product_outputs/football/day11/FOOTBALL_DAY11_MANAGER_REPORT.md [full_copy]
- research/product_outputs/football/day11/football_day11_decisions.csv [preview_only]
- research/product_outputs/football/day11/football_day11_decisions.jsonl [preview_only]
- research/product_outputs/football/day11/football_day11_product_manifest.json [full_copy]
- research/product_outputs/football/day12/FOOTBALL_DAY12_EXPERIMENTAL_CANDIDATE_REPORT.md [full_copy]
- research/product_outputs/football/day12/football_day12_candidates.csv [preview_only]
- research/product_outputs/football/day12/football_day12_candidates.jsonl [preview_only]
- research/product_outputs/football/day12/football_day12_product_manifest.json [full_copy]
- research/product_outputs/football/latest/FOOTBALL_CURRENT_STATUS.md [full_copy]
- research/product_outputs/football/latest/FOOTBALL_DECISIONS.md [full_copy]
- research/product_outputs/football/latest/FOOTBALL_EXPERIMENTAL_CANDIDATES.md [full_copy]
- research/product_outputs/football/latest/FOOTBALL_MODEL_PRICES.md [full_copy]
- research/product_outputs/football/latest/football_decisions.csv [preview_only]
- research/product_outputs/football/latest/football_decisions_sample.csv [full_copy]
- research/product_outputs/football/latest/football_experimental_candidates.csv [preview_only]
- research/product_outputs/football/latest/football_experimental_candidates_sample.csv [full_copy]
- research/product_outputs/football/latest/football_model_prices.csv [preview_only]
- research/product_outputs/football/latest/football_model_prices.jsonl [preview_only]
- research/product_outputs/football/latest/football_model_prices_sample.csv [full_copy]
- research/product_outputs/football/latest/football_pipeline_manifest.json [full_copy]
- research/spec_migration/FOOTBALL_DAY10_ACCEPTANCE_AUDIT_2026-08-18.md [full_copy]
- research/spec_migration/FOOTBALL_DAY11A_ACCEPTANCE_AUDIT_2026-08-19.md [full_copy]
- research/spec_migration/FOOTBALL_DAY12_ACCEPTANCE_AUDIT_2026-08-19.md [full_copy]
- research/spec_migration/FULL_SPEC_ALIGNMENT_AUDIT_2026-08-17.md [full_copy]
- research/spec_migration/FULL_SPEC_ALIGNMENT_AUDIT_2026-08-19.md [full_copy]

## Notes

- large `.jsonl` and database artifacts are previewed or referenced rather than fully copied when they would bloat the handoff
- this bundle is intended to be uploaded to ChatGPT instead of the entire heavy repo