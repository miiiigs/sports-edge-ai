"""Provider abstraction for current football fixtures."""

from __future__ import annotations

import json
import os
from abc import ABC, abstractmethod
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass
from datetime import date, datetime, timedelta, timezone
from pathlib import Path
from threading import Lock
from typing import Any

import httpx

from ..data_sources.football_history import DIVISION_TO_COMPETITION
from .models import (
    FIXTURE_STATUS_CANCELLED,
    FIXTURE_STATUS_FINISHED,
    FIXTURE_STATUS_HALFTIME,
    FIXTURE_STATUS_LIVE,
    FIXTURE_STATUS_POSTPONED,
    FIXTURE_STATUS_PRE_MATCH,
    FIXTURE_STATUS_SCHEDULED,
    NormalizedFixture,
    build_fixture_id,
    utc_now_iso,
)

API_FOOTBALL_SOURCE_VERSION = "api_football_fixture_adapter_v1"
API_FOOTBALL_PROVIDER = "api-football"

_STATUS_MAP = {
    "NS": FIXTURE_STATUS_PRE_MATCH,
    "TBD": FIXTURE_STATUS_SCHEDULED,
    "PST": FIXTURE_STATUS_POSTPONED,
    "CANC": FIXTURE_STATUS_CANCELLED,
    "ABD": FIXTURE_STATUS_CANCELLED,
    "AWD": FIXTURE_STATUS_CANCELLED,
    "WO": FIXTURE_STATUS_CANCELLED,
    "HT": FIXTURE_STATUS_HALFTIME,
    "FT": FIXTURE_STATUS_FINISHED,
    "AET": FIXTURE_STATUS_FINISHED,
    "PEN": FIXTURE_STATUS_FINISHED,
    "1H": FIXTURE_STATUS_LIVE,
    "2H": FIXTURE_STATUS_LIVE,
    "ET": FIXTURE_STATUS_LIVE,
    "BT": FIXTURE_STATUS_LIVE,
    "INT": FIXTURE_STATUS_LIVE,
    "SUSP": FIXTURE_STATUS_LIVE,
}


class FixtureProviderError(RuntimeError):
    """Raised when fixture retrieval fails."""


class FixtureProviderNotConfiguredError(FixtureProviderError):
    """Raised when a provider cannot be used because required config is absent."""


@dataclass(frozen=True)
class FixtureProviderConfig:
    display_timezone: str = "Asia/Manila"
    timeout_seconds: float = 20.0
    league_map_env_var: str = "SPORTS_AI_API_FOOTBALL_LEAGUE_MAP"
    token_env_var: str = "SPORTS_AI_API_FOOTBALL_TOKEN"


class FixtureProvider(ABC):
    """Normalized fixture provider contract."""

    @abstractmethod
    def provider_name(self) -> str:
        raise NotImplementedError

    @abstractmethod
    def configured(self) -> bool:
        raise NotImplementedError

    @abstractmethod
    def get_live_fixtures(self) -> list[NormalizedFixture]:
        raise NotImplementedError

    @abstractmethod
    def get_fixtures_for_date(self, target_date: date) -> list[NormalizedFixture]:
        raise NotImplementedError

    @abstractmethod
    def get_upcoming_fixtures(
        self,
        *,
        from_utc: datetime,
        to_utc: datetime,
    ) -> list[NormalizedFixture]:
        raise NotImplementedError

    @abstractmethod
    def get_fixture(self, fixture_id: str) -> NormalizedFixture | None:
        raise NotImplementedError


class ApiFootballFixtureProvider(FixtureProvider):
    """Current fixture provider backed by API-Football."""

    def __init__(self, config: FixtureProviderConfig | None = None):
        self._config = FixtureProviderConfig() if config is None else config
        self._cached_league_map: dict[str, int] | None = None
        self._query_log: list[dict[str, Any]] = []
        self._query_log_lock = Lock()

    def provider_name(self) -> str:
        return API_FOOTBALL_PROVIDER

    def configured(self) -> bool:
        return bool(os.environ.get(self._config.token_env_var, "").strip()) and bool(self._league_map_path())

    def _league_map_path(self) -> Path | None:
        raw_value = os.environ.get(self._config.league_map_env_var, "").strip()
        if not raw_value:
            return None
        path = Path(raw_value)
        return path if path.exists() else None

    def _token(self) -> str:
        token = os.environ.get(self._config.token_env_var, "").strip()
        if not token:
            raise FixtureProviderNotConfiguredError(
                f"missing required environment variable {self._config.token_env_var}"
            )
        return token

    def _league_map(self) -> dict[str, int]:
        if self._cached_league_map is not None:
            return dict(self._cached_league_map)
        path = self._league_map_path()
        if path is None:
            raise FixtureProviderNotConfiguredError(
                f"missing readable league map from {self._config.league_map_env_var}"
            )
        payload = json.loads(path.read_text(encoding="utf-8"))
        if not isinstance(payload, dict):
            raise FixtureProviderError("API-Football league map must be a JSON object")
        self._cached_league_map = {
            str(key): int(value)
            for key, value in payload.items()
        }
        return dict(self._cached_league_map)

    def _client(self) -> httpx.Client:
        return httpx.Client(
            follow_redirects=True,
            timeout=self._config.timeout_seconds,
            headers={"x-apisports-key": self._token()},
        )

    def reset_sync_diagnostics(self) -> None:
        with self._query_log_lock:
            self._query_log = []

    def sync_diagnostics(self) -> dict[str, Any]:
        with self._query_log_lock:
            queries = [dict(entry) for entry in self._query_log]
        errors = [entry for entry in queries if entry.get("errors")]
        league_ids = sorted(
            {
                int(entry["provider_league_id"])
                for entry in queries
                if entry.get("provider_league_id") is not None
            }
        )
        seasons = sorted(
            {
                str(entry["provider_season"])
                for entry in queries
                if entry.get("provider_season") not in {None, ""}
            }
        )
        return {
            "provider": API_FOOTBALL_PROVIDER,
            "query_count": len(queries),
            "league_ids_queried": league_ids,
            "provider_seasons_queried": seasons,
            "has_errors": bool(errors),
            "last_error": None if not errors else dict(errors[-1]),
            "queries": queries,
        }

    def _request_fixtures(self, *, params: dict[str, Any]) -> list[dict[str, Any]]:
        with self._client() as client:
            response = client.get("https://v3.football.api-sports.io/fixtures", params=params)
            response.raise_for_status()
            payload = response.json()
        errors_payload = payload.get("errors")
        errors = errors_payload if isinstance(errors_payload, dict) else {}
        rows = payload.get("response")
        if not isinstance(rows, list):
            raise FixtureProviderError("unexpected API-Football fixtures response payload")
        diagnostic_entry = {
            "query_timestamp": utc_now_iso(),
            "provider": API_FOOTBALL_PROVIDER,
            "http_status": int(response.status_code),
            "response_status": "OK" if not errors else "ERROR",
            "provider_league_id": params.get("league"),
            "provider_season": params.get("season"),
            "params": {str(key): value for key, value in params.items()},
            "response_results": int(payload.get("results") or 0),
            "raw_fixture_count": len(rows),
            "errors": errors,
        }
        with self._query_log_lock:
            self._query_log.append(diagnostic_entry)
        return rows

    def _division_code_for_league_id(self, league_id: int) -> str | None:
        for division_code, configured_id in self._league_map().items():
            if configured_id == league_id:
                return division_code
        return None

    def _normalize_fixture(self, payload: dict[str, Any]) -> NormalizedFixture | None:
        fixture_payload = payload.get("fixture") or {}
        league_payload = payload.get("league") or {}
        teams_payload = payload.get("teams") or {}
        goals_payload = payload.get("goals") or {}

        league_id = league_payload.get("id")
        if league_id is None:
            return None
        division_code = self._division_code_for_league_id(int(league_id))
        if division_code is None:
            return None

        competition_id, default_competition_name = DIVISION_TO_COMPETITION.get(
            division_code,
            (division_code, division_code),
        )
        raw_kickoff = str(fixture_payload.get("date") or "").strip()
        kickoff_utc = raw_kickoff.replace("Z", "+00:00")
        status_payload = fixture_payload.get("status") or {}
        status_short = str(status_payload.get("short") or "").upper()
        normalized_status = _STATUS_MAP.get(status_short, FIXTURE_STATUS_PRE_MATCH)

        home_team = teams_payload.get("home") or {}
        away_team = teams_payload.get("away") or {}
        home_name = str(home_team.get("name") or "").strip()
        away_name = str(away_team.get("name") or "").strip()
        provider_fixture_id = str(fixture_payload.get("id") or "").strip() or None
        fixture_id = build_fixture_id(
            provider=API_FOOTBALL_PROVIDER,
            provider_fixture_id=provider_fixture_id,
            kickoff_utc=kickoff_utc,
            home_team_name=home_name,
            away_team_name=away_name,
        )
        score_home = goals_payload.get("home")
        score_away = goals_payload.get("away")

        return NormalizedFixture(
            fixture_id=fixture_id,
            provider_fixture_id=provider_fixture_id,
            provider=API_FOOTBALL_PROVIDER,
            competition_id=str(competition_id),
            competition_name=str(league_payload.get("name") or default_competition_name),
            division_code=division_code,
            season=str(league_payload.get("season") or ""),
            home_team_id=str(home_team.get("id") or "").strip() or None,
            home_team_name=home_name,
            away_team_id=str(away_team.get("id") or "").strip() or None,
            away_team_name=away_name,
            kickoff_utc=kickoff_utc,
            status=normalized_status,
            elapsed_minute=None
            if status_payload.get("elapsed") is None
            else int(status_payload.get("elapsed")),
            home_score=None if score_home is None else int(score_home),
            away_score=None if score_away is None else int(score_away),
            last_provider_update=utc_now_iso(),
            source_version=API_FOOTBALL_SOURCE_VERSION,
            provider_payload=payload,
        )

    def _dedupe(self, fixtures: list[NormalizedFixture]) -> list[NormalizedFixture]:
        deduped: dict[str, NormalizedFixture] = {}
        for fixture in fixtures:
            deduped[fixture.fixture_id] = fixture
        return sorted(deduped.values(), key=lambda item: (item.kickoff_utc, item.fixture_id))

    def get_live_fixtures(self) -> list[NormalizedFixture]:
        if not self.configured():
            raise FixtureProviderNotConfiguredError("API-Football is not configured")
        league_ids = set(self._league_map().values())
        rows = self._request_fixtures(params={"live": "all"})
        fixtures = []
        for row in rows:
            league_id = int(((row.get("league") or {}).get("id") or 0))
            if league_id not in league_ids:
                continue
            normalized = self._normalize_fixture(row)
            if normalized is not None and normalized.status in {
                FIXTURE_STATUS_LIVE,
                FIXTURE_STATUS_HALFTIME,
            }:
                fixtures.append(normalized)
        return self._dedupe(fixtures)

    def get_fixtures_for_date(self, target_date: date) -> list[NormalizedFixture]:
        if not self.configured():
            raise FixtureProviderNotConfiguredError("API-Football is not configured")
        target_date_text = target_date.isoformat()
        fixtures: list[NormalizedFixture] = []
        league_items = sorted(self._league_map().items())

        def fetch_league_rows(item: tuple[str, int]) -> tuple[str, list[dict[str, Any]]]:
            division_code, league_id = item
            rows = self._request_fixtures(
                params={
                    "date": target_date_text,
                    "league": league_id,
                    "season": target_date.year,
                }
            )
            return division_code, rows

        with ThreadPoolExecutor(max_workers=min(5, max(1, len(league_items)))) as executor:
            for division_code, rows in executor.map(fetch_league_rows, league_items):
                for row in rows:
                    normalized = self._normalize_fixture(row)
                    if normalized is None:
                        continue
                    if normalized.division_code != division_code:
                        continue
                    if normalized.kickoff_utc[:10] != target_date_text:
                        continue
                    fixtures.append(normalized)
        return self._dedupe(fixtures)

    def get_upcoming_fixtures(
        self,
        *,
        from_utc: datetime,
        to_utc: datetime,
    ) -> list[NormalizedFixture]:
        if not self.configured():
            raise FixtureProviderNotConfiguredError("API-Football is not configured")
        fixtures: list[NormalizedFixture] = []
        current_date = from_utc.astimezone(timezone.utc).date()
        final_date = to_utc.astimezone(timezone.utc).date()
        while current_date <= final_date:
            fixtures.extend(self.get_fixtures_for_date(current_date))
            current_date += timedelta(days=1)
        lower = from_utc.astimezone(timezone.utc)
        upper = to_utc.astimezone(timezone.utc)
        filtered = [
            fixture
            for fixture in fixtures
            if lower <= datetime.fromisoformat(fixture.kickoff_utc) <= upper
            and fixture.status in {
                FIXTURE_STATUS_SCHEDULED,
                FIXTURE_STATUS_PRE_MATCH,
            }
        ]
        return self._dedupe(filtered)

    def get_fixture(self, fixture_id: str) -> NormalizedFixture | None:
        if not fixture_id.startswith(f"{API_FOOTBALL_PROVIDER}:"):
            return None
        provider_fixture_id = fixture_id.split(":", 1)[1]
        if provider_fixture_id.startswith("generated:"):
            return None
        rows = self._request_fixtures(params={"id": provider_fixture_id})
        if not rows:
            return None
        return self._normalize_fixture(rows[0])
